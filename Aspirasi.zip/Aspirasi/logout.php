<?php
session_start();
require_once 'assets/config/koneksi.php';
if (!isset($_SESSION["login"])) {
    echo "<script>location='index.php?page=login'</script>";
}
$ses = @$_SESSION["username"];
mysqli_query($koneksi, "update pengguna set status='offline' where username='$ses'");
session_unset();
session_destroy();
echo "<script>location='index.php?page=login'</script>";
