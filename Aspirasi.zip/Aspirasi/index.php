<?php
session_start();
require_once __DIR__ . '/assets/config/koneksi.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- meta google -->
    <meta name="url" content="https://<?= $_SERVER["HTTP_HOST"]; ?>/">
    <meta name="keywords" content="forum, sosmed, chat, posting">
    <meta name="description" content="forum penyampaian aspirasi ke hmj tekkom">
    <meta name="author" content="M. Amal Ikhsani">
    <meta name="copyright" content="<?= date("Y-m-d") ?>">
    <meta name="application-name" content="Forum Aspirasi">

    <!-- meta OG -->
    <meta property="og:title" content="Forum Aspirasi">
    <meta property="og:keywords" content="forum, sosmed, chat, posting">
    <meta property="og:description" content="forum penyampaian aspirasi ke hmj tekkom">
    <meta property="og:url" content="https://<?= $_SERVER["HTTP_HOST"]; ?>/">
    <meta property="og:image" content="https://<?= $_SERVER["HTTP_HOST"]; ?>/assets/imgs/favicon.ico">

    <!-- sc icon -->
    <link rel="shortcut icon" href="assets/imgs/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/imgs/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/imgs/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/imgs/favicon-16x16.png">
    <link rel="manifest" href="assets/imgs/site.webmanifest">

    <!-- bootstrap css -->
    <link rel="stylesheet" href="assets/css/stylee.css">
    <link rel="stylesheet" href="assets/css/customess.css">

    <title>Forum Aspirasi - Forum penyampaian aspirasi ke hmj tekkom</title>
    <script>
        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        }
    </script>
</head>

<body class="bg-dark">
    <nav class="navbar navbar-expand-lg navbar-dark sticky-top bg-dark shadow">
        <div class="container-lg">
            <a class="navbar-brand fs-3 fw-semibold text-success" href="?page=forum">ASPIRASI</a>
            <form class="mx-auto my-2 col-4 d-none d-lg-flex" role="search" method="get">
                <input class="form-control rounded-0 rounded-start shadow-sm border border-success border-2 bg-dark text-secondary" name="q" type="search" placeholder="Search" aria-label="Search" required autocomplete="off">
                <button class="btn btn-success rounded-0 rounded-end shadow-sm" type="submit"><i class="bi bi-search"></i></button>
            </form>
            <?php if (!isset($_SESSION["login"])) { ?>
                <a href="?page=login" class="btn btn-outline-success border-0"><i class="bi bi-person-fill me-2"></i>Login</a>
            <?php } else { ?>
                <div class="nav-item dropdown text-success">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <?= ucfirst($_SESSION["username"]) ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end dropdown-menu-dark mt-3 rounded-0 bg-dark">
                        <li><a class="dropdown-item" href="?page=profil-detail&profil=<?= $_SESSION["username"] ?>">Profil</a></li>
                        <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                    </ul>
                </div>
            <?php } ?>
        </div>
    </nav>
    <div class="bg-success bg-opacity-10" style="height:200px;">
        <div class="container-lg">
            <div class="row" style="min-height:200px;">
                <div class="col-lg-10 mx-auto my-4 my-sm-5">
                    <div class="card bg-success bg-opacity-25 shadow-sm border-0">
                        <div class="card-header px-2">
                            <p class="mb-0 text-light" style="line-height:2rem;">
                                <i class="bi bi-megaphone-fill py-2 px-4 bg-dark text-light rounded me-2"></i>
                                Selamat datang di <span class="text-success">ASPIRASI</span> | Sampaikan Aspirasimu ke HMJ TEKKOM.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <?php
                    $page = @$_GET["page"];
                    switch ($page) {
                        case 'forum':
                            require_once 'assets/layouts/forum.php';
                            break;
                        case 'form':
                            require_once 'assets/layouts/form.php';
                            break;
                        case 'post':
                            require_once 'assets/layouts/post.php';
                            break;
                        case 'login':
                            require_once 'assets/layouts/login.php';
                            break;
                        case 'postingan':
                            require_once 'assets/layouts/postingan.php';
                            break;
                        case 'postingan-detail':
                            require_once 'assets/layouts/postingan-detail.php';
                            break;
                        case 'profil':
                            require_once 'assets/layouts/profil.php';
                            break;
                        case 'profil-detail':
                            require_once 'assets/layouts/profil-detail.php';
                            break;

                        default:
                            require_once 'assets/layouts/forum.php';
                            break;
                    }
                    ?>
                </div>
                <p class="text-center my-4 text-secondary">Copyright &copy; <?= date("Y") ?></p>
            </div>
        </div>
    </div>

    <script src="assets/js/script.js"></script>
</body>

</html>