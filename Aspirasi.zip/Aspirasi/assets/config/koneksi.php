<?php

$koneksi = mysqli_connect("localhost", "root", "", "forum");
if (!$koneksi) {
    die("Error connecting to aspirasi") . mysqli_connect_error();
}

if (isset($_POST["register"])) {
    $un = htmlspecialchars(strtolower($_POST["username"]));
    if (strlen($un) == null) {
        return false;
    } else if (strlen($un) > 50) {
        return false;
    }
    $em = htmlspecialchars($_POST["email"]);
    if (strlen($em) == null) {
        return false;
    } else if (strlen($em) > 50) {
        return false;
    } else if (!filter_var($em, FILTER_VALIDATE_EMAIL)) {
        return false;
    }
    $pw = htmlspecialchars($_POST["password"]);
    if (strlen($pw) == null) {
        return false;
    } else if (strlen($pw) > 300) {
        return false;
    }
    $pw2 = htmlspecialchars($_POST["password2"]);
    if (strlen($pw2) == null) {
        return false;
    } else if (strlen($pw2) > 300) {
        return false;
    }
    // cek username
    $result = mysqli_query($koneksi, "select*from pengguna where username='$un'");
    if (mysqli_num_rows($result) == 0) {
        if ($pw == $pw2) {
            $pass = password_hash($pw, PASSWORD_DEFAULT);
            $date = date("Y-m-d H:i:s");
            $sql = mysqli_query($koneksi, "insert into pengguna values(null,'$un','$em','hai kawan kawan','$pass','kayu',null,'$date')");
            if ($sql) {
                echo "<script>alert('Berhasil register')</script>";
                echo "<script>location='?page=login'</script>";
                return $sql;
            }
        } else {
            echo "<script>alert('Password konfirmasi salah')</script>";
            echo "<script>location='?page=login'</script>";
            return false;
        }
    } else {
        echo "<script>alert('Username telah digunakan')</script>";
        echo "<script>location='?page=login'</script>";
        return false;
    }
}

if (isset($_POST["login"])) {
    $un = htmlspecialchars($_POST["username"]);
    if (strlen($un) == null) {
        return false;
    } else if (strlen($un) > 50) {
        return false;
    }
    $pw = htmlspecialchars($_POST["password"]);
    if (strlen($pw) == null) {
        return false;
    } else if (strlen($pw) > 300) {
        return false;
    }
    $qry = mysqli_query($koneksi, "select*from pengguna");
    while ($d = mysqli_fetch_assoc($qry)) {
        if ($un == $d["username"]) {
            if (password_verify($pw, $d["password"])) {
                $_SESSION["login"] = true;
                $_SESSION["username"] = $d["username"];
                $_SESSION["bio"] = $d["bio"];
                $_SESSION["email"] = $d["email"];
                $_SESSION["pangkat"] = $d["pangkat"];
                $_SESSION["status"] = $d["status"];
                $_SESSION["tanggal"] = $d["tanggal"];

                $qry = mysqli_query($koneksi, "update pengguna set status='online' where username='$un'");
                if ($qry) {
                    echo "<script>alert('Berhasil login')</script>";
                    echo "<script>location='?page=forum'</script>";
                    return $qry;
                }
            }
        }
    }
}

if (isset($_POST["post"])) {
    $judul = htmlspecialchars($_POST["judul"]);
    if (strlen($judul) == null) {
        return false;
    } else if (strlen($judul) > 50) {
        return false;
    }
    $isi = htmlspecialchars($_POST["isi"]);
    if (strlen($isi) == null) {
        return false;
    } else if (strlen($isi) > 500) {
        return false;
    }
    $name = htmlspecialchars($_SESSION["username"]);
    $tgl = date("Y-m-d H:i:s");
    $qry = mysqli_query($koneksi, "insert into posting values(null,'$judul','$isi','$name','$tgl')");
    if ($qry) {
        echo "<script>alert('Posting berhasil')</script>";
        echo "<script>location='?page=post'</script>";
    } else {
        echo "<script>alert('Posting gagal')</script>";
        echo "<script>location='?page=post'</script>";
    }
}

function url($text)
{
    $text = html_entity_decode($text);
    $text = "" . $text;
    $text = preg_replace('/(https{0,1}:\/\/[\w\-\.\/#?&=]*)/', '<a href="$1" target="_blank">$1</a>', $text);
    return $text;
}

$ses = @$_SESSION["username"];
$num = mysqli_num_rows(mysqli_query($koneksi, "select*from posting where username='$ses'"));
if ($num == 3) {
    mysqli_query($koneksi, "update pengguna set pangkat='batu' where username='$ses'");
} else if ($num == 9) {
    mysqli_query($koneksi, "update pengguna set pangkat='besi' where username='$ses'");
} else if ($num == 27) {
    mysqli_query($koneksi, "update pengguna set pangkat='perak' where username='$ses'");
} else if ($num == 81) {
    mysqli_query($koneksi, "update pengguna set pangkat='emas' where username='$ses'");
} else if ($num == 243) {
    mysqli_query($koneksi, "update pengguna set pangkat='permata' where username='$ses'");
} else if ($num == 729) {
    mysqli_query($koneksi, "update pengguna set pangkat='berlian' where username='$ses'");
} else if ($num == 2187) {
    mysqli_query($koneksi, "update pengguna set pangkat='diamond' where username='$ses'");
}

if (isset($_POST["kirim"])) {
    $username = htmlspecialchars($_SESSION["username"]);
    $chat = htmlspecialchars($_POST["chat"]);
    if (strlen($chat) == null) {
        return false;
    } else if (strlen($chat) > 50) {
        return false;
    }
    $date = date("Y-m-d H:i:s");

    mysqli_query($koneksi, "insert into chat values(null,'$username','$chat','$date')");
}

function nicetime($date)
{
    if (empty($date)) {
        return "No date provided";
    }

    $periods         = array("detik", "menit", "jam", "hari", "minggu", "bulan", "tahun", "dekade");
    $lengths         = array("60", "60", "24", "7", "4.35", "12", "10");

    $now             = time();
    $unix_date         = strtotime($date);

    // check validity of date
    if (empty($unix_date)) {
        return "Error";
    }

    // is it future date or past date
    if ($now > $unix_date) {
        $difference     = $now - $unix_date;
        $tense         = "yang lalu";
    } else {
        $difference     = $unix_date - $now;
        $tense         = "[baru]";
    }

    for ($j = 0; $difference >= $lengths[$j] && $j < count($lengths) - 1; $j++) {
        $difference /= $lengths[$j];
    }

    $difference = round($difference);

    if ($difference == 0) {
        $difference = "beberapa";
    }

    return "$difference $periods[$j] {$tense}";
}
