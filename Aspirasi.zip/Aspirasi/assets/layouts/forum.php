<div class="card bg-dark rounded-0 rounded-top border-0 shadow">
    <div class="card-header rounded-0 py-3">
        <nav aria-label="breadcrumb" style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='9'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='%236c757d'/%3E%3C/svg%3E&#34;);">
            <a href="?page=post" class="btn btn-success py-0 px-2 float-end"><i class="bi bi-folder-plus me-1"></i>Post</a>
            <ol class="breadcrumb m-0">
                <li class="breadcrumb-item"><a href="?page=forum" class="text-decoration-none"><i class="bi bi-house-fill me-2"></i>Forum Aspirasi</a></li>
            </ol>
        </nav>
    </div>
    <div class="card-body">
        <?php
        if (isset($_SESSION["login"])) {
        ?>
            <div class="card bg-dark border-0 shadow mb-3">
                <div class="card-header bg-success bg-opacity-25 text-white">
                    <a class="text-white float-end" data-bs-toggle="collapse" href="#collapseExample3" role="button" aria-expanded="false" aria-controls="collapseExample"><i class="bi bi-grid-fill"></i></a>
                    <h6 class="mb-0 my-1"><i class="bi bi-chat-fill me-2"></i>Live Chat</h6>
                </div>
                <div class="collapse show" id="collapseExample3">
                    <div class="card-body bg-dark text-secondary py-1">
                        <div class="row" style="height:290px;overflow-y:scroll;" id="chat">
                        </div>
                    </div>
                    <div class="card-footer">
                        <form action="" method="post" class="d-flex">
                            <input type="text" name="chat" class="form-control bg-dark text-secondary border border-0 border-bottom border-start border-success shadow me-2" placeholder="Tulis Pesan" autocomplete="off" autofocus required>
                            <button type="submit" name="kirim" class="btn btn-success"><i class="bi bi-send"></i></button>
                        </form>
                    </div>
                    <script>
                        const chatBox = document.getElementById("chat");

                        function scrollToBottom() {
                            chatBox.scrollTo(0, chatBox.scrollHeight);
                        }

                        chatBox.onmouseenter = () => {
                            chatBox.classList.add('active');
                        }

                        chatBox.onmouseleave = () => {
                            chatBox.classList.remove('active');
                        }

                        function loadXMLDocs() {
                            var xhttp = new XMLHttpRequest();
                            xhttp.onreadystatechange = function() {
                                if (this.readyState == 4 && this.status == 200) {
                                    document.getElementById("chat").innerHTML =
                                        this.responseText;
                                    if (!chatBox.classList.contains('active')) {
                                        scrollToBottom()
                                    }

                                }
                            };
                            xhttp.open("GET", "assets/layouts/livechat.php", true);
                            xhttp.send();
                        }


                        setInterval(function() {
                            loadXMLDocs();
                        }, 0.1)
                        window.onload = loadXMLDocs();
                    </script>
                </div>
            </div>
        <?php
        }
        ?>
        <div class="card bg-dark border-0 shadow mb-3">
            <div class="card-header bg-success bg-opacity-25 text-white">
                <a class="text-white float-end" data-bs-toggle="collapse" href="#collapseExample2" role="button" aria-expanded="false" aria-controls="collapseExample"><i class="bi bi-grid-fill"></i></a>
                <h6 class="mb-0 my-1"><i class="bi bi-folder-fill me-2"></i>Postingan</h6>
            </div>
            <div class="collapse show" id="collapseExample2">
                <div class="card-body bg-dark text-secondary">
                    <?php
                    if (isset($_GET["q"])) {
                        $q = htmlspecialchars($_GET["q"]);
                        $result = mysqli_query($koneksi, "select*from posting where judul like '%$q%' or isi like '%$q%' or username like '%$q%' or tanggal like '%$q%'");
                    } else {
                        $result = mysqli_query($koneksi, "select*from posting order by rand()");
                    }
                    while ($d = mysqli_fetch_assoc($result)) {
                    ?>
                        <div class="row justify-content-between my-2">
                            <div class="col-lg-1 text-center">
                                <i class="bi bi-folder-fill fs-1 text-secondary"></i>
                            </div>
                            <div class="col-lg-9 mb-2 mb-lg-0" style="border-left:1px dotted;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;">
                                <a href="?page=postingan-detail&post=<?= $d["id"] ?>" class="text-decoration-none fs-5 fw-semibold" style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;"><?= ucfirst($d["judul"]) ?></a>
                                <p class="text-start text-secondary mb-0" style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;"><?= ucfirst(url($d["isi"])) ?></p>
                            </div>
                            <div class="col-lg-2 py-1" style="border-left:1px dotted;">
                                <p class="mb-1">Ditulis oleh :</p>
                                <h6 class="mb-0 text-secondary fw-semibold"><?= ucfirst($d["username"]) ?></h6>
                            </div>
                        </div>
                    <?php
                    }
                    ?>
                </div>
            </div>
        </div>
        <div class="card bg-dark border-0 shadow mb-3">
            <div class="card-header bg-success bg-opacity-25 text-white">
                <a class="text-white float-end" data-bs-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample"><i class="bi bi-grid-fill"></i></a>
                <h6 class="mb-0 my-1"><i class="bi bi-people-fill me-2"></i>Profil</h6>
            </div>
            <div class="collapse show" id="collapseExample">
                <div class="card-body bg-dark text-secondary">
                    <?php
                    if (isset($_GET["q"])) {
                        $q = htmlspecialchars($_GET["q"]);
                        $result1 = mysqli_query($koneksi, "select*from pengguna where username like '%$q%' or bio like '%$q%' or pangkat like '%$q%' or tanggal like '%$q%'");
                    } else {
                        $result1 = mysqli_query($koneksi, "select*from pengguna order by rand()");
                    }
                    $i = 1;
                    while ($d = mysqli_fetch_assoc($result1)) {
                    ?>
                        <div class="row justify-content-between my-2">
                            <div class="col-lg-1 text-center">
                                <i class="bi bi-person-fill fs-1 text-secondary"></i>
                            </div>
                            <div class="col-lg-9 mb-2 mb-lg-0" style="border-left:1px dotted;">
                                <a href="?page=profil-detail&profil=<?= $d["username"] ?>" class="text-decoration-none fs-5 fw-semibold" style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;"><?= ucfirst($d["username"]) ?></a>
                                <p class="text-start text-secondary mb-0" style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;"><?= ucfirst(url($d["bio"])) ?></p>
                            </div>
                            <div class="col-lg-2 py-1" style="border-left:1px dotted;">
                                <p class="mb-1">Tanggal dibuat :</p>
                                <h6 class="mb-0 text-secondary fw-semibold"><?= $d["tanggal"] ?></h6>
                            </div>
                        </div>
                    <?php
                    }
                    ?>
                </div>
            </div>
        </div>
        <div class="card bg-dark border-0 shadow mb-3">
            <div class="card-header bg-success bg-opacity-25 text-white">
                <a class="text-white float-end" data-bs-toggle="collapse" href="#collapseExample1" role="button" aria-expanded="false" aria-controls="collapseExample"><i class="bi bi-grid-fill"></i></a>
                <h6 class="mb-0 my-1"><i class="bi bi-book-fill me-2"></i>Form</h6>
            </div>
            <div class="collapse show" id="collapseExample1">
                <div class="card-body bg-dark text-secondary">
                    <div class="row justify-content-between my-2">
                        <div class="col-lg-1 text-center">
                            <i class="bi bi-person-fill fs-1 text-secondary"></i>
                        </div>
                        <div class="col-lg-9 mb-2 mb-lg-0" style="border-left:1px dotted;">
                            <a href="?page=login" class="text-decoration-none fs-5 fw-semibold">Login</a>
                            <p class="text-start text-secondary mb-0">Kamu harus login agar bisa post aspirasimu</p>
                        </div>
                        <div class="col-lg-2 py-1" style="border-left:1px dotted;">
                            <p class="mb-1">Dibuat oleh :</p>
                            <h6 class="mb-0 text-secondary fw-semibold">Forum Aspirasi</h6>
                        </div>
                    </div>
                    <div class="row justify-content-between my-2">
                        <div class="col-lg-1 text-center">
                            <i class="bi bi-folder-fill fs-1 text-secondary"></i>
                        </div>
                        <div class="col-lg-9 mb-2 mb-lg-0" style="border-left:1px dotted;">
                            <a href="?page=post" class="text-decoration-none fs-5 fw-semibold">Post</a>
                            <p class="text-start text-secondary mb-0">Posting aspirasimu sekarang juga</p>
                        </div>
                        <div class="col-lg-2 py-1" style="border-left:1px dotted;">
                            <p class="mb-1">Dibuat oleh :</p>
                            <h6 class="mb-0 text-secondary fw-semibold">Forum Aspirasi</h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card bg-dark border-0 shadow mb-3">
            <div class="card-header bg-success bg-opacity-25 text-white">
                <a class="text-white float-end" data-bs-toggle="collapse" href="#collapseExample0" role="button" aria-expanded="false" aria-controls="collapseExample"><i class="bi bi-grid-fill"></i></a>
                <h6 class="mb-0 my-1"><i class="bi bi-bezier2 me-2"></i>Grafik Pangkat</h6>
            </div>
            <div class="collapse show" id="collapseExample0">
                <div class="card-body bg-dark text-secondary">
                    <?php
                    $data0 = mysqli_num_rows(mysqli_query($koneksi, "select*from pengguna"));
                    $data1 = mysqli_num_rows(mysqli_query($koneksi, "select*from pengguna where pangkat='kayu'"));
                    $data2 = mysqli_num_rows(mysqli_query($koneksi, "select*from pengguna where pangkat='batu'"));
                    $data3 = mysqli_num_rows(mysqli_query($koneksi, "select*from pengguna where pangkat='besi'"));
                    $data4 = mysqli_num_rows(mysqli_query($koneksi, "select*from pengguna where pangkat='perak'"));
                    $data5 = mysqli_num_rows(mysqli_query($koneksi, "select*from pengguna where pangkat='emas'"));
                    $data6 = mysqli_num_rows(mysqli_query($koneksi, "select*from pengguna where pangkat='permata'"));
                    $data7 = mysqli_num_rows(mysqli_query($koneksi, "select*from pengguna where pangkat='berlian'"));
                    $data8 = mysqli_num_rows(mysqli_query($koneksi, "select*from pengguna where pangkat='diamond'")); ?>
                    <div class="d-sm-block d-none">
                        <canvas id="myChart" width="100%" height="35"></canvas>
                    </div>
                    <div class="d-sm-none d-block">
                        <canvas id="myChart2" width="100%" height="100"></canvas>
                    </div>
                    <script src="assets/js/charts.js"></script>
                    <script>
                        const ctx = document.getElementById('myChart2').getContext('2d');
                        const myChart = new Chart(ctx, {
                            type: 'line',
                            data: {
                                labels: ['kayu', 'batu', 'besi', 'perak', 'emas', 'permata', 'berlian', 'diamond'],
                                datasets: [{
                                    label: 'Pengguna',
                                    data: [<?= $data1 ?>, <?= $data2 ?>, <?= $data3 ?>, <?= $data4 ?>, <?= $data5 ?>, <?= $data6 ?>, <?= $data7 ?>, <?= $data8 ?>],
                                    backgroundColor: [
                                        'rgba(111, 66, 193)'
                                    ],
                                    borderColor: [
                                        'rgb(111, 66, 193)',
                                    ],
                                    borderWidth: 2
                                }]
                            },
                            options: {
                                animations: {
                                    tension: {
                                        duration: 1000,
                                        easing: 'linear',
                                        from: 1,
                                        to: 0,
                                        loop: true
                                    }
                                },
                                plugins: {
                                    subtitle: {
                                        display: true,
                                        text: '<?= $data0 ?> Pengguna'
                                    }
                                },
                                scales: {
                                    y: {
                                        min: 0,
                                        max: <?= $data0 + 3 ?>
                                    }
                                }
                            }
                        });
                        const ctxs = document.getElementById('myChart').getContext('2d');
                        const myChart2 = new Chart(ctxs, {
                            type: 'line',
                            data: {
                                labels: ['kayu [0 post]', 'batu [3 post]', 'besi [9 post]', 'perak [27 post]', 'emas [81 post]', 'permata [243 post]', 'berlian [729 post]', 'diamond [2187 post]'],
                                datasets: [{
                                    label: 'Pengguna',
                                    data: [<?= $data1 ?>, <?= $data2 ?>, <?= $data3 ?>, <?= $data4 ?>, <?= $data5 ?>, <?= $data6 ?>, <?= $data7 ?>, <?= $data8 ?>],
                                    backgroundColor: [
                                        'rgba(111, 66, 193)'
                                    ],
                                    borderColor: [
                                        'rgb(111, 66, 193)',
                                    ],
                                    borderWidth: 2
                                }]
                            },
                            options: {
                                animations: {
                                    tension: {
                                        duration: 1000,
                                        easing: 'linear',
                                        from: 1,
                                        to: 0,
                                        loop: true
                                    }
                                },
                                plugins: {
                                    subtitle: {
                                        display: true,
                                        text: '<?= $data0 ?> Pengguna'
                                    }
                                },
                                scales: {
                                    y: {
                                        min: 0,
                                        max: <?= $data0 + 3 ?>
                                    }
                                }
                            }
                        });
                    </script>
                </div>
            </div>
        </div>
    </div>
    <div class="card-footer">
        <div class="row justify-content-center">
            <div class="col-lg-2 text-center">
                <p class="text-secondary my-2">
                    <?php
                    $result = mysqli_query($koneksi, "select*from posting");
                    $data = mysqli_num_rows($result);
                    echo $data . " Postingan";
                    ?>
                </p>
            </div>
            <div class="col-lg-2 text-center">
                <p class="text-secondary my-2">
                    <?php
                    $result = mysqli_query($koneksi, "select*from pengguna");
                    $data = mysqli_num_rows($result);
                    echo $data . " Pengguna";
                    ?>
                </p>
            </div>
            <div class="col-lg-2 text-center">
                <p class="text-secondary my-2">
                    <?php
                    $result = mysqli_query($koneksi, "select*from pengguna where status='online'");
                    $data = mysqli_num_rows($result);
                    echo $data . " Sedang Online";
                    ?>
                </p>
            </div>
        </div>
    </div>
</div>