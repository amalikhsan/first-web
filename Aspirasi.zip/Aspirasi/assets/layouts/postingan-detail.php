<?php
$post = htmlspecialchars($_GET["post"]);
$result = mysqli_query($koneksi, "select*from posting where id='$post'");
if (mysqli_num_rows($result) > 0) {
    while ($d = mysqli_fetch_assoc($result)) {
?>
        <div class="card bg-dark rounded-0 rounded-top border-0 shadow">
            <div class="card-header rounded-0 py-3">
                <nav aria-label="breadcrumb" style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='9'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='%236c757d'/%3E%3C/svg%3E&#34;);">
                    <a href="?page=post" class="btn btn-success py-0 px-2 float-end"><i class="bi bi-folder-plus me-1"></i>Post</a>
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="?page=forum" class="text-decoration-none"><i class="bi bi-house-fill me-2"></i>Forum Aspirasi</a></li>
                        <li class="breadcrumb-item"><a href="?page=postingan" class="text-decoration-none">Postingan</a></li>
                        <li class="breadcrumb-item active"><?= ucfirst($d["judul"]) ?></li>
                    </ol>
                </nav>
            </div>
            <div class="card-body">
                <div class="card bg-dark border-0 shadow mb-3">
                    <div class="card-header bg-success bg-opacity-25 text-white">
                        <h6 class="mb-0 my-1"><i class="bi bi-folder-fill me-2"></i>Postingan <?= ucfirst($d["username"]) ?></h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-4 text-center d-none d-lg-block">
                                <div class="card bg-success bg-opacity-10 p-3 my-2">
                                    <a href="?page=profil-detail&profil=<?= $d["username"] ?>" class="text-center text-decoration-none fs-3 fw-bold"><?= ucfirst($d["username"]) ?></a>
                                    <i class="bi bi-person-fill display-1 text-secondary my-3"></i>
                                    <p class="text-secondary text-center mb-4">
                                        <?php
                                        $username = $d["username"];
                                        $result1 = mysqli_query($koneksi, "select*from posting where username='$username'");
                                        $data = mysqli_num_rows($result1);
                                        echo $data . " Postingan";
                                        ?> |
                                        <?php
                                        $username = $d["username"];
                                        $result1 = mysqli_query($koneksi, "select*from pengguna where username='$username' and status='online'");
                                        if (mysqli_num_rows($result1) > 0) {
                                            echo "Online";
                                        }
                                        ?>
                                    </p>
                                    <div class="bg-dark p-3 text-start rounded">
                                        <?php
                                        $username = $d["username"];
                                        $result = mysqli_query($koneksi, "select*from pengguna where username='$username'");
                                        while ($dt = mysqli_fetch_assoc($result)) {
                                        ?>
                                            <p class="text-secondary mb-0">Nama :</p>
                                            <p class="text-secondary"><?= ucfirst($dt["username"]) ?></p>
                                            <p class="text-secondary mb-0">Bio :</p>
                                            <p class="text-secondary"><?= ucfirst($dt["bio"]) ?></p>
                                            <p class="text-secondary mb-0">Email :</p>
                                            <p class="text-secondary"><?= ucfirst($dt["email"]) ?></p>
                                            <p class="text-secondary mb-0">Tanggal :</p>
                                            <p class="text-secondary"><?= ucfirst($dt["tanggal"]) ?></p>
                                            <p class="text-secondary mb-0">Pangkat :</p>
                                            <p class="text-secondary"><?= ucfirst($dt["pangkat"]) ?></p>
                                            <p class="text-secondary mb-0">Status :</p>
                                            <p class="text-secondary"><?= ucfirst($dt["status"]) ?></p>
                                        <?php
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-8 text-center">
                                <div class="card bg-dark text-secondary p-4 shadow my-2">
                                    <h6 class="fs-3 fw-semibold text-secondary"><?= ucfirst($d["judul"]) ?></h6>
                                    <p class="text-secondary mb-4"><?= $d["tanggal"] ?></p>
                                    <p class="text-secondary text-start"><?= ucfirst(url($d["isi"])) ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php
    }
} else {
    echo "<script>location='?page=postingan'</script>";
}
?>