<?php
$post = htmlspecialchars($_GET["profil"]);
$result = mysqli_query($koneksi, "select*from pengguna where username='$post'");
if (mysqli_num_rows($result) > 0) {
    while ($d = mysqli_fetch_assoc($result)) {
        $ids = $d["id"];
        if (isset($_POST["edit$ids"])) {
            $name = $d["username"];
            $bio = htmlspecialchars($_POST["bio"]);
            if (strlen($bio) == null) {
                return false;
            } else if (strlen($bio) > 50) {
                return false;
            }
            $qry = mysqli_query($koneksi, "update pengguna set bio='$bio'");
            if ($qry) {
                echo "<script>alert('Edit berhasil')</script>";
                echo "<script>location='?page=profil-detail&profil=$name'</script>";
            } else {
                echo "<script>alert('Edit gagal')</script>";
                echo "<script>location='?page=profil-detail&profil=$name'</script>";
            }
        }
?>
        <div class="card bg-dark rounded-0 rounded-top border-0 shadow">
            <div class="card-header rounded-0 py-3">
                <nav aria-label="breadcrumb" style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='9'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='%236c757d'/%3E%3C/svg%3E&#34;);">
                    <a href="?page=post" class="btn btn-success py-0 px-2 float-end"><i class="bi bi-folder-plus me-1"></i>Post</a>
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="?page=forum" class="text-decoration-none"><i class="bi bi-house-fill me-2"></i>Forum Aspirasi</a></li>
                        <li class="breadcrumb-item"><a href="?page=profil" class="text-decoration-none">Profil</a></li>
                        <li class="breadcrumb-item active"><?= ucfirst($d["username"]) ?></li>
                    </ol>
                </nav>
            </div>
            <div class="card-body">
                <div class="card bg-dark border-0 shadow mb-3">
                    <div class="card-header bg-success bg-opacity-25 text-white">
                        <h6 class="mb-0 my-1"><i class="bi bi-folder-fill me-2"></i>Profil <?= ucfirst($d["username"]) ?></h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12 text-center">
                                <div class="card bg-success bg-opacity-10 p-3 my-2">
                                    <a href="?page=profil-detail&profil=<?= $d["username"] ?>" class="text-center text-decoration-none fs-3 fw-bold"><?= ucfirst($d["username"]) ?></a>
                                    <i class="bi bi-person-fill display-1 text-secondary my-3"></i>
                                    <p class="text-secondary text-center mb-4">
                                        <?php
                                        $username = $d["username"];
                                        $result1 = mysqli_query($koneksi, "select*from posting where username='$username'");
                                        $data = mysqli_num_rows($result1);
                                        echo $data . " Postingan";
                                        ?> |
                                        <?php
                                        $username = $d["username"];
                                        $result1 = mysqli_query($koneksi, "select*from pengguna where username='$username' and status='online'");
                                        if (mysqli_num_rows($result1) > 0) {
                                            echo "Online";
                                        }
                                        ?>
                                        <?php
                                        if (@$_SESSION["username"] == $d["username"]) {
                                            echo " "; ?>
                                            | <a href="#" data-bs-toggle="modal" data-bs-target="#exampleModal">Edit Bio</a>
                                        <?php
                                        }
                                        ?>

                                    </p>
                                    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content bg-dark text-secondary">
                                                <div class="modal-header border-0">
                                                    <h5 class="modal-title" id="exampleModalLabel">Edit Bio</h5>
                                                    <button type="button" class="fs-4 border-0 bg-transparent text-secondary" data-bs-dismiss="modal" aria-label="Close"><i class="bi bi-x"></i></button>
                                                </div>
                                                <form action="" method="post">
                                                    <div class="modal-body">
                                                        <input type="text" name="bio" class="form-control bg-dark text-secondary border-0 border-bottom border-start border-success shadow mb-3" placeholder="Edit Bio" value="<?= $d["bio"] ?>" autocomplete="off" required>
                                                    </div>
                                                    <div class="modal-footer border-0">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                        <button type="submit" name="edit<?= $d["id"] ?>" class="btn btn-success">Simpan Perubahan</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="bg-dark p-3 text-lg-center text-start rounded">
                                        <?php
                                        $username = $d["username"];
                                        $result = mysqli_query($koneksi, "select*from pengguna where username='$username'");
                                        while ($dt = mysqli_fetch_assoc($result)) {
                                        ?>
                                            <div class="row">
                                                <div class="col-lg-2">
                                                    <p class="text-secondary mb-0">Nama :</p>
                                                    <p class="text-secondary mb-lg-1 mb-2"><?= ucfirst($dt["username"]) ?></p>
                                                </div>
                                                <div class="col-lg-2">
                                                    <p class="text-secondary mb-0">Bio :</p>
                                                    <p class="text-secondary mb-lg-1 mb-2"><?= ucfirst(url($dt["bio"])) ?></p>
                                                </div>
                                                <div class="col-lg-2">
                                                    <p class="text-secondary mb-0">Email :</p>
                                                    <p class="text-secondary mb-lg-1 mb-2"><?= ucfirst($dt["email"]) ?></p>
                                                </div>
                                                <div class="col-lg-2">
                                                    <p class="text-secondary mb-0">Tanggal :</p>
                                                    <p class="text-secondary mb-lg-1 mb-2"><?= ucfirst($dt["tanggal"]) ?></p>
                                                </div>
                                                <div class="col-lg-2">
                                                    <p class="text-secondary mb-0">Pangkat :</p>
                                                    <p class="text-secondary mb-lg-1 mb-2"><?= ucfirst($dt["pangkat"]) ?></p>
                                                </div>
                                                <div class="col-lg-2 my-auto">
                                                    <p class="text-secondary mb-0">Status :</p>
                                                    <p class="text-secondary mb-lg-1 mb-2"><?= ucfirst($dt["status"]) ?></p>
                                                </div>
                                            </div>
                                        <?php
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="card bg-dark text-secondary p-4 shadow my-2">
                                    <?php
                                    if (isset($_GET["q"])) {
                                        $q = htmlspecialchars($_GET["q"]);
                                        $username = $d["username"];
                                        $result = mysqli_query($koneksi, "select*from posting where username='$username' and judul like '%$q%' or isi like '%$q%' or username like '%$q%' or tanggal like '%$q%'");
                                    } else {
                                        $username = $d["username"];
                                        $result = mysqli_query($koneksi, "select*from posting where username='$username'");
                                    }
                                    while ($d = mysqli_fetch_assoc($result)) {
                                    ?>
                                        <div class="row justify-content-between my-2">
                                            <div class="col-lg-1 text-center">
                                                <i class="bi bi-folder-fill fs-1 text-secondary"></i>
                                            </div>
                                            <div class="col-lg-9 mb-2 mb-lg-0" style="border-left:1px dotted;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;">
                                                <a href="?page=postingan-detail&post=<?= $d["id"] ?>" class="text-decoration-none fs-5 fw-semibold"><?= ucfirst($d["judul"]) ?></a>
                                                <p class="text-start text-secondary mb-0" style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;"><?= $d["isi"] ?></p>
                                            </div>
                                            <div class="col-lg-2 py-1" style="border-left:1px dotted;">
                                                <p class="mb-1">Ditulis oleh :</p>
                                                <h6 class="mb-0 text-secondary fw-semibold"><?= ucfirst($d["username"]) ?></h6>
                                            </div>
                                        </div>
                                    <?php
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php
    }
} else {
    echo "<script>location='?page=postingan'</script>";
}
?>