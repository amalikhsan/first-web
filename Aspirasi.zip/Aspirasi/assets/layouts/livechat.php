<?php
require_once '../config/koneksi.php';
$result = mysqli_query($koneksi, "select*from chat");
while ($d = mysqli_fetch_assoc($result)) {
?>
    <div class="col-12">
        <p class="mb-0 float-end d-none d-lg-inline"><?= nicetime($d["tanggal"]) ?></p>
        <p class="mb-0"><a href="?page=profil-detail&profil=<?= $d["username"] ?>" class="text-decoration-none"><i class="bi bi-person-fill me-2"></i><?= ucfirst($d["username"]) ?></a> : <?= $d["pesan"] ?></p>
    </div>
<?php
}
?>