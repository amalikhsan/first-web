<div class="card bg-dark rounded-0 rounded-top border-0 shadow">
    <div class="card-header rounded-0 py-3">
        <nav aria-label="breadcrumb" style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='9'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='%236c757d'/%3E%3C/svg%3E&#34;);">
            <a href="?page=post" class="btn btn-success py-0 px-2 float-end"><i class="bi bi-folder-plus me-1"></i>Post</a>
            <ol class="breadcrumb m-0">
                <li class="breadcrumb-item"><a href="?page=forum" class="text-decoration-none"><i class="bi bi-house-fill me-2"></i>Forum Aspirasi</a></li>
                <li class="breadcrumb-item active">Profil</li>
            </ol>
        </nav>
    </div>
    <div class="card-body">
        <div class="card bg-dark border-0 shadow mb-3">
            <div class="card-header bg-success bg-opacity-25 text-white">
                <a class="text-white float-end" data-bs-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample"><i class="bi bi-grid-fill"></i></a>
                <h6 class="mb-0 my-1"><i class="bi bi-people-fill me-2"></i>Profil</h6>
            </div>
            <div class="collapse show" id="collapseExample">
                <div class="card-body bg-dark text-secondary">
                    <?php
                    if (isset($_GET["q"])) {
                        $q = $_GET["q"];
                        $result1 = mysqli_query($koneksi, "select*from pengguna where username like '%$q%' or bio like '%$q%' or pangkat like '%$q%' or tanggal like '%$q%'");
                    } else {
                        $result1 = mysqli_query($koneksi, "select*from pengguna order by rand()");
                    }
                    $i = 1;
                    while ($d = mysqli_fetch_assoc($result1)) {
                    ?>
                        <div class="row justify-content-between my-2">
                            <div class="col-lg-1 text-center">
                                <i class="bi bi-person-fill fs-1 text-secondary"></i>
                            </div>
                            <div class="col-lg-9 mb-2 mb-lg-0" style="border-left:1px dotted;">
                                <a href="?page=profil-detail&profil=<?= $d["username"] ?>" class="text-decoration-none fs-5 fw-semibold" style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;"><?= ucfirst($d["username"]) ?></a>
                                <p class="text-start text-secondary mb-0" style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;"><?= ucfirst(url($d["bio"])) ?></p>
                            </div>
                            <div class="col-lg-2 py-1" style="border-left:1px dotted;">
                                <p class="mb-1">Tanggal dibuat :</p>
                                <h6 class="mb-0 text-secondary fw-semibold"><?= $d["tanggal"] ?></h6>
                            </div>
                        </div>
                    <?php
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>