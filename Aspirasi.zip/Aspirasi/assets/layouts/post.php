<?php
if (!isset($_SESSION["login"])) {
    header("location:?page=login");
}
?>
<div class="card bg-dark rounded-0 rounded-top border-0 shadow">
    <div class="card-header rounded-0 py-3">
        <nav aria-label="breadcrumb" style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='9'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='%236c757d'/%3E%3C/svg%3E&#34;);">
            <a href="?page=post" class="btn btn-success py-0 px-2 float-end"><i class="bi bi-folder-plus me-1"></i>Post</a>
            <ol class="breadcrumb m-0">
                <li class="breadcrumb-item"><a href="?page=forum" class="text-decoration-none"><i class="bi bi-house-fill me-2"></i>Forum Aspirasi</a></li>
                <li class="breadcrumb-item"><a href="?page=form" class="text-decoration-none">Form</a></li>
                <li class="breadcrumb-item active">Post</li>
            </ol>
        </nav>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-4 text-center d-none d-lg-block">
                <div class="card bg-success bg-opacity-10 p-3 my-2">
                    <a href="?page=profil-detail&profil=<?= $_SESSION["username"] ?>" class="text-center text-decoration-none fs-3 fw-bold"><?= ucfirst($_SESSION["username"]) ?></a>
                    <i class="bi bi-person-fill display-1 text-secondary my-3"></i>
                    <p class="text-secondary text-center mb-4">
                        <?php
                        $username = $_SESSION["username"];
                        $result1 = mysqli_query($koneksi, "select*from posting where username='$username'");
                        $data = mysqli_num_rows($result1);
                        echo $data . " Postingan";
                        ?> |
                        <?php
                        $username = $_SESSION["username"];
                        $result1 = mysqli_query($koneksi, "select*from pengguna where username='$username' and status='online'");
                        if (mysqli_num_rows($result1) > 0) {
                            echo "Online";
                        }
                        ?>
                    </p>
                    <div class="bg-dark p-3 text-start rounded">
                        <p class="text-secondary mb-0">Nama :</p>
                        <p class="text-secondary"><?= $_SESSION["username"] ?></p>
                        <p class="text-secondary mb-0">Bio :</p>
                        <p class="text-secondary"><?= $_SESSION["bio"] ?></p>
                        <p class="text-secondary mb-0">Email :</p>
                        <p class="text-secondary"><?= $_SESSION["email"] ?></p>
                        <p class="text-secondary mb-0">Tanggal :</p>
                        <p class="text-secondary"><?= $_SESSION["tanggal"] ?></p>
                        <p class="text-secondary mb-0">Pangkat :</p>
                        <p class="text-secondary"><?= $_SESSION["pangkat"] ?></p>
                        <p class="text-secondary mb-0">Status :</p>
                        <p class="text-secondary"><?= $_SESSION["status"] ?></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-8 my-2">
                <div class="card bg-dark border-0 shadow mb-3">
                    <div class="card-header bg-success bg-opacity-25 text-white">
                        <h6 class="mb-0 my-1"><i class="bi bi-folder-plus me-2"></i>Form Post</h6>
                    </div>
                    <div class="card-body">
                        <form action="" method="post">
                            <input type="text" name="judul" class="form-control bg-dark text-secondary border border-0 border-bottom border-start border-success shadow mb-3" placeholder="Judul" autocomplete="off" required>
                            <textarea type="text" name="isi" rows="5" class="form-control bg-dark text-secondary border border-0 border-bottom border-start border-success shadow mb-3" placeholder="Isi Post" style="resize: none !important;" autocomplete="off" required></textarea>
                            <button type="submit" name="post" class="btn btn-success w-100">Login</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>